<div align="center">
  <img src="portada.png" alt="Cover" width="800"/>
</div>

# BPSR Meter - Enhanced Edition v2.5.0

**The Ultimate Hybrid**: Combining the best features from multiple BPSR Meter versions

[![License](https://img.shields.io/badge/License-AGPL--3.0-blue)](LICENSE)
[![Version](https://img.shields.io/badge/Version-2.5.0-green)](https://github.com/mrsnakke/BPSR-Meter)

---

## 🌟 What Makes This Enhanced?

This version combines:
- ✨ **NeRooNx's beautiful modern UI** - Glassmorphism, rank badges, clean design
- ⚡ **MrSnake's robust data engine** - Accurate DPS/HPS tracking, proper packet parsing
- 🔧 **Performance optimizations** - Native webkit dragging (not sluggish JS dragging)
- 🐛 **All bugs fixed** - Alt+Tab, window focus, duplicates removed
- 🌍 **Complete English translation** - No more Spanish text

---

# Acknowledgments and Credits

This project combines work from multiple talented developers:

- **dmlgzs** - Original [StarResonanceDamageCounter](https://github.com/dmlgzs/StarResonanceDamageCounter)
- **MrSnakeVT** - Major improvements and bug fixes  
- **NeRooNx** - Modern UI redesign ([NeRooNx/BPSR-Meter](https://github.com/NeRooNx/BPSR-Meter))
- **Enhanced Edition** - Ultimate hybrid combining the best of all versions

See [AUTHORS.md](AUTHORS.md) for detailed contributor information.

---

# BPSR Meter - DPS Meter for Blue Protocol

BPSR Meter is a desktop application that acts as a real-time DPS (Damage Per Second) meter for Blue Protocol. It overlays the game window to provide detailed combat statistics without interrupting your gameplay.

![DPS Meter in action](medidor.png)

## ✨ Enhanced Features

### Core Features
1.  **Player Name:** Your identifier in the meter
2.  **Current/Max Health:** Visual health bar with color coding
3.  **DPS (Damage Per Second):** Real-time damage dealt per second
4.  **HPS (Healing Per Second):** Real-time healing done per second
5.  **Total Damage:** Accumulated damage in encounter
6.  **Damage Taken:** Total damage received during combat
7.  **Contribution %:** Your percentage of the group's total damage
8.  **Total Healing:** Accumulated healing in encounter
9.  **GS (Gear Score):** Equipment and skill score

### Enhanced UI Features
- 🥇 **Rank Badges** - Gold/Silver/Bronze for top 3 players
- 💙 **Local Player Highlighting** - Blue glow on your character with pulsing animation
- 🎨 **Position Gradient** - Background colors from red (#1) to blue (#10)
- 📊 **Nearby/Solo Modes** - View top 10 or just yourself
- 🔄 **Multi-Metric Sorting** - Sort by DMG, TANK, or HEAL
- ⚡ **Smooth Animations** - Professional transitions and hover effects
- 🎯 **Clean Modern Design** - Glassmorphism with blur effects

### Performance Enhancements
- ⚡ **Native Window Dragging** - Snappy, responsive movement (not sluggish)
- ⚡ **Optimized Rendering** - 50ms update interval with efficient DOM updates
- ⚡ **Smart Click-Through** - Auto-enables when hovering controls
- ⚡ **Efficient Event Handling** - No performance degradation

### Quality of Life
- ⌨️ **F10 Hotkey** - Quick reset
- 🔄 **Auto-Sync Timer** - 80-second auto-clear when idle
- 🎯 **Visual Feedback** - All actions have smooth animations
- 🔒 **Improved Lock Mode** - Better always-on-top behavior

---

> ### Responsible Use
> This tool is designed to help you improve your own performance. **Please do not use it to degrade, harass, or discriminate against other players.** The goal is self-improvement and enjoying the game as a community.

## Installation

### Prerequisites
1. **Install Npcap:** The application requires Npcap to capture the game's network traffic.
   - Download from: https://npcap.com/
   - ✅ Enable "WinPcap API-compatible Mode"
   - ✅ Enable "Support loopback traffic"

2. **Download the installer:** Go to the "Releases" section and download `BPSR Meter Setup 2.5.0.exe`

3. **Run the installer:** Execute as Administrator and follow the instructions

---

## How to Use

### Basic Usage
1. **Launch BPSR Meter** (as Administrator)
2. **Start Blue Protocol**
3. **Enter combat** - The meter will automatically start tracking
4. **Change instance once** if data doesn't appear (first launch)

### Window Controls

| Button | Function | Hotkey |
|--------|----------|--------|
| ⋮⋮ | Drag to move window | - |
| 🔒/🔓 | Lock/unlock position | - |
| 🔄 | Manual sync/refresh | - |
| Reset | Clear all statistics | F10 |
| ✕ | Close application | - |

### View Modes

**Nearby Mode** (Default):
- Shows top 10 players sorted by selected metric
- If you're outside top 10, you appear as 11th with real position number
- DMG/TANK/HEAL sorting buttons visible

**Solo Mode**:
- Shows only your personal statistics
- Clean focused view for self-improvement
- Sorting buttons hidden

### Sorting Options (Nearby Mode)

Click the buttons to sort players by:
- **DMG**: Total damage dealt (default)
- **TANK**: Total damage taken
- **HEAL**: Total healing done

---

## 🔧 Building from Source

### Windows Build
```powershell
# Install Node.js 22+
winget install OpenJS.NodeJS

# Install pnpm
npm install -g pnpm@10.13.1

# Clone and build
git clone https://github.com/yourrepo/BPSR-Meter.git
cd BPSR-Meter
pnpm install
pnpm dist
```

### Linux/WSL Build (Cross-compile)
```bash
# Install dependencies
sudo apt-get install libpcap-dev build-essential
npm install -g pnpm@10.13.1

# Build
cd /development/BPSR-Meter
pnpm install
pnpm build  # Creates Windows .exe
```

---

## Troubleshooting

### Application Issues

**No data showing:**
1. Install Npcap with WinPcap compatibility
2. Run BPSR Meter as Administrator
3. Start Blue Protocol before the meter
4. Change instance/channel once (forces packet capture)
5. Check firewall isn't blocking

**Window is sluggish/slow to drag:**
- ✅ **FIXED in Enhanced Edition!**
- Now uses native webkit dragging
- Smooth and responsive

**Alt+Tab hides window behind game:**
- ✅ **FIXED in Enhanced Edition!**
- Enhanced always-on-top with focus handlers
- Window stays visible

**Players showing as "Unknown":**
- Change instance/channel
- Wait 5-10 seconds for packet capture
- Check network adapter selection in logs

**Sorting doesn't work properly:**
- ✅ **FIXED in Enhanced Edition!**
- Robust sorting with proper data handling
- Click DMG/TANK/HEAL to change sort

### Build Issues

**"cap" compilation fails:**
```bash
# Linux/WSL:
sudo apt-get install libpcap-dev

# Windows:
npm install -g windows-build-tools
```

**Python not found:**
```bash
# Install Python 3.11+
# Windows: winget install Python.Python.3.11
```

**Electron builder fails:**
```bash
# Windows only - install Visual Studio Build Tools
winget install Microsoft.VisualStudio.BuildTools
```

---

## Frequently Asked Questions (FAQ)

**Is using this meter a bannable offense?**
> It operates in a "gray area." It doesn't modify game files, inject code, or alter the game's memory. Historically, tools that only read data have an extremely low risk of being banned. However, **use it at your own risk.**

**Does it affect my game's performance (FPS)?**
> No. The impact is virtually zero, as packet capturing is a passive and very lightweight process.

**Why does it need to run as an administrator?**
> To allow the Npcap library to have low-level access to network adapters and monitor the game's packets.

**What's different from the original version?**
> This Enhanced Edition combines NeRooNx's modern UI with MrSnake's data accuracy, adds performance fixes, and includes complete English translation.

**Does it work with ExitLag?**
> Yes, but set ExitLag to "Legacy-NDIS" mode and allow 30 seconds out of combat for auto-clear.

**Does it work on the Chinese server?**
> Yes, it works correctly on the Chinese server.

**Can I contribute?**
> Yes! Pull requests are welcome. Please test thoroughly and follow the existing code style.

---

## 📊 Version History

### v2.5.0 - Enhanced Edition (Latest)
- ✅ Hybrid UI combining NeRooNx + MrSnake
- ✅ Native webkit dragging (performance fix)
- ✅ Nearby/Solo modes with multi-metric sorting
- ✅ Rank badges and local player highlighting
- ✅ Complete English translation
- ✅ All known bugs fixed

### v2.4.1 - MrSnake Version
- F10 hotkey
- Manual reset
- VC++ redistributables
- Window movement fixes

### v1.0.0 - NeRooNx Version
- Modern UI redesign
- Nearby/Solo modes
- Rank badges

### v2.3.0 - Original
- Base functionality
- DPS/HPS tracking

---

## Social Media

[![Twitch](https://img.shields.io/badge/Twitch-9146FF?style=for-the-badge&logo=twitch&logoColor=white)](https://www.twitch.tv/mrsnakevt)
[![Kick](https://img.shields.io/badge/Kick-50FF78?style=for-the-badge&logo=kick&logoColor=white)](https://kick.com/mrsnakevt)
[![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@MrSnake_VT)
[![X (Twitter)](https://img.shields.io/badge/X-000000?style=for-the-badge&logo=x&logoColor=white)](https://x.com/MrSnakeVT)
