// BPSR Meter - Enhanced Edition
// Hybrid combining NeRooNx UI with MrSnake data handling

// Global state
let viewMode = 'nearby'; // 'nearby' or 'solo'
let sortColumn = 'totalDmg'; // Default sort column
let sortDirection = 'desc'; // 'asc' or 'desc'
let isLocked = false; // Window lock state
let currentMouseEventsState = true; // true = ignoring events (click-through), false = allowing events

// Auto-sync timer state
const SYNC_RESET_TIME = 80; // Seconds for automatic reset
let syncTimerInterval;
let syncCountdown = 0;
let syncTimerDisplayTimeout;

// Tracking variables
let lastTotalDamage = 0;
let lastDamageChangeTime = Date.now();
let lastStartTime = 0; // Timestamp to detect server resets

// Profession mapping with role detection
const professionMap = {
    // Main Classes - Chinese to English with accurate roles
    '雷影剑士': { name: 'Stormblade', icon: 'Stormblade.png', role: 'dps', isTank: false, isHealer: false },
    '冰魔导师': { name: 'Frost Mage', icon: 'Frost Mage.png', role: 'dps', isTank: false, isHealer: false },
    '涤罪恶火·战斧': { name: 'Fire Axe', icon: 'Fire Axe.png', role: 'dps', isTank: false, isHealer: false },
    '青岚骑士': { name: 'Wind Knight', icon: 'Wind Knight.png', role: 'tank', isTank: true, isHealer: false },
    '森语者': { name: 'Verdant Oracle', icon: 'Verdant Oracle.png', role: 'healer', isTank: false, isHealer: true },
    '雷霆一闪·手炮': { name: 'Gunner', icon: 'desconocido.png', role: 'dps', isTank: false, isHealer: false },
    '巨刃守护者': { name: 'Heavy Guardian', icon: 'baluarte_ferreo.png', role: 'tank', isTank: true, isHealer: false },
    '暗灵祈舞·仪刀/仪仗': { name: 'Spirit Dancer', icon: 'desconocido.png', role: 'dps', isTank: false, isHealer: false },
    '神射手': { name: 'Marksman', icon: 'arco_halcon.png', role: 'dps', isTank: false, isHealer: false },
    '神盾骑士': { name: 'Shield Knight', icon: 'guardian.png', role: 'tank', isTank: true, isHealer: false },
    '灵魂乐手': { name: 'Soul Musician', icon: 'sonido_feroz.png', role: 'dps', isTank: false, isHealer: false },

    // Specializations with role detection
    '居合': { name: 'Iaido Slash', icon: 'Stormblade.png', role: 'dps', isTank: false, isHealer: false },
    '月刃': { name: 'MoonStrike', icon: 'MoonStrike.png', role: 'dps', isTank: false, isHealer: false },
    '冰矛': { name: 'Icicle', icon: 'lanza_hielo.png', role: 'dps', isTank: false, isHealer: false },
    '射线': { name: 'Frostbeam', icon: 'Frost Mage.png', role: 'dps', isTank: false, isHealer: false },
    '防盾': { name: 'Vanguard', icon: 'guardian.png', role: 'tank', isTank: true, isHealer: false },
    '岩盾': { name: 'Skyward', icon: 'Fire Axe.png', role: 'tank', isTank: true, isHealer: false },
    '惩戒': { name: 'Smite', icon: 'castigo.png', role: 'dps', isTank: false, isHealer: false },
    '愈合': { name: 'Lifebind', icon: 'Verdant Oracle.png', role: 'healer', isTank: false, isHealer: true },
    '格挡': { name: 'Block', icon: 'guardian.png', role: 'tank', isTank: true, isHealer: false },
    '狼弓': { name: 'Wildpack', icon: 'arco_lobo.png', role: 'dps', isTank: false, isHealer: false },
    '鹰弓': { name: 'Falconry', icon: 'arco_halcon.png', role: 'dps', isTank: false, isHealer: false },
    '光盾': { name: 'Shield', icon: 'egida_luz.png', role: 'tank', isTank: true, isHealer: false },
    '协奏': { name: 'Concerto', icon: 'Concierto.png', role: 'dps', isTank: false, isHealer: false },
    '狂音': { name: 'Dissonance', icon: 'sonido_feroz.png', role: 'dps', isTank: false, isHealer: false },
    '空枪': { name: 'Empty Gun', icon: 'francotirador.png', role: 'dps', isTank: false, isHealer: false },
    '重装': { name: 'Heavy Armor', icon: 'Wind Knight.png', role: 'tank', isTank: true, isHealer: false },
};

const defaultProfession = { name: 'Unknown', icon: 'desconocido.png', role: 'unknown', isTank: false, isHealer: false };

// DOM Elements
const playerBarsContainer = document.getElementById('player-bars-container');
const syncButton = document.getElementById('sync-button');
const syncIcon = document.querySelector('#sync-button .sync-icon');
const syncTimerSpan = document.querySelector('#sync-button .sync-timer');
const lockButton = document.getElementById('lock-button');
const loadingIndicator = document.getElementById('loading-indicator');

// Keyboard handlers
document.addEventListener('keydown', (e) => {
    // F10 to reset
    if (e.key === 'F10') {
        e.preventDefault();
        resetDpsMeter();
    }
    // Alt key for interaction when locked
    if (e.key === 'Alt' && isLocked) {
        document.body.classList.add('alt-pressed');
    }
});

document.addEventListener('keyup', (e) => {
    if (e.key === 'Alt') {
        document.body.classList.remove('alt-pressed');
    }
});

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', () => {
    setupEventHandlers();
    console.log('BPSR Meter Enhanced Edition initialized');
});

function setupEventHandlers() {
    // Reset button
    const resetButton = document.getElementById('reset-button');
    if (resetButton) {
        resetButton.addEventListener('click', () => {
            resetDpsMeter();
        });
    }

    // Nearby/Solo toggle
    const nearbySoloBtn = document.getElementById('nearby-solo-btn');
    const sortDmgBtn = document.getElementById('sort-dmg-btn');
    const sortTankBtn = document.getElementById('sort-tank-btn');
    const sortHealBtn = document.getElementById('sort-heal-btn');
    
    if (nearbySoloBtn) {
        nearbySoloBtn.addEventListener('click', () => {
            viewMode = viewMode === 'nearby' ? 'solo' : 'nearby';
            nearbySoloBtn.textContent = viewMode === 'nearby' ? 'Nearby' : 'Solo';
            nearbySoloBtn.classList.toggle('solo', viewMode === 'solo');
            
            // Show/hide sort buttons based on mode
            const sortButtons = [sortDmgBtn, sortTankBtn, sortHealBtn];
            sortButtons.forEach(btn => {
                if (btn) {
                    btn.style.display = viewMode === 'solo' ? 'none' : 'flex';
                }
            });
            
            fetchDataAndRender();
        });
    }

    // Sort buttons
    function updateSortButtons(activeButton) {
        [sortDmgBtn, sortTankBtn, sortHealBtn].forEach(btn => {
            if (btn) btn.classList.remove('active');
        });
        if (activeButton) activeButton.classList.add('active');
    }

    if (sortDmgBtn) {
        sortDmgBtn.addEventListener('click', () => {
            sortColumn = 'totalDmg';
            sortDirection = 'desc';
            updateSortButtons(sortDmgBtn);
            fetchDataAndRender();
        });
    }

    if (sortTankBtn) {
        sortTankBtn.addEventListener('click', () => {
            sortColumn = 'dmgTaken';
            sortDirection = 'desc';
            updateSortButtons(sortTankBtn);
            fetchDataAndRender();
        });
    }

    if (sortHealBtn) {
        sortHealBtn.addEventListener('click', () => {
            sortColumn = 'totalHeal';
            sortDirection = 'desc';
            updateSortButtons(sortHealBtn);
            fetchDataAndRender();
        });
    }

    // Sync button
    if (syncButton) {
        syncButton.addEventListener('click', async () => {
            // Visual feedback
            syncButton.style.opacity = '0.5';
            syncButton.style.pointerEvents = 'none';
            
            await fetch('/api/clear');
            console.log('Meter reset.');
            
            lastTotalDamage = 0;
            lastDamageChangeTime = Date.now();
            stopSyncTimer();
            
            await fetchDataAndRender();
            
            setTimeout(() => {
                syncButton.style.opacity = '1';
                syncButton.style.pointerEvents = 'auto';
            }, 300);
        });
    }

    // Lock button
    if (lockButton) {
        lockButton.addEventListener('click', () => {
            if (window.electronAPI) {
                window.electronAPI.toggleLockState();
            }
        });

        // Listen for lock state changes from main process
        if (window.electronAPI) {
            window.electronAPI.onLockStateChanged((locked) => {
                isLocked = locked;
                lockButton.innerHTML = isLocked ? '<i class="fa-solid fa-lock"></i>' : '<i class="fa-solid fa-lock-open"></i>';
                lockButton.title = isLocked ? 'Unlock position' : 'Lock position';
                
                const dpsMeter = document.querySelector('.dps-meter');
                if (dpsMeter) {
                    dpsMeter.classList.toggle('locked', isLocked);
                }
                
                document.body.classList.toggle('locked', isLocked);
                updateClickThroughState();
            });
        }
    }

    // Close button
    const closeButton = document.getElementById('close-button');
    if (closeButton) {
        closeButton.addEventListener('click', () => {
            if (window.electronAPI) {
                window.electronAPI.closeWindow();
            }
        });
    }
}

// Click-through control system
// Simplified click-through using only CSS pointer-events
// Window always accepts mouse events at Electron level
// CSS controls what elements are clickable
function updateClickThroughState() {
    const controls = document.querySelector('.controls');
    const lockBtn = document.getElementById('lock-button');
    const playerBars = document.getElementById('player-bars-container');
    
    if (isLocked) {
        // Locked mode: only lock button works, everything else click-through
        if (controls) controls.style.pointerEvents = 'none';
        if (lockBtn) lockBtn.style.pointerEvents = 'auto';
        if (playerBars) playerBars.style.pointerEvents = 'none';
    } else {
        // Unlocked: controls work, player bars click-through
        if (controls) controls.style.pointerEvents = 'auto';
        if (playerBars) playerBars.style.pointerEvents = 'none';
    }
}

// Reset function
function resetDpsMeter() {
    fetch('/api/clear');
    console.log('Meter reset.');
    lastTotalDamage = 0;
    lastDamageChangeTime = Date.now();
    stopSyncTimer();
}

// Sync timer functions
function updateSyncButtonState() {
    if (!syncIcon || !syncTimerSpan) return;
    
    clearTimeout(syncTimerDisplayTimeout);

    if (syncTimerInterval) { // Timer is active
        if (syncCountdown <= 60) {
            // Show countdown
            syncIcon.style.display = 'none';
            syncTimerSpan.innerText = `${syncCountdown}s`;
            syncTimerSpan.style.display = 'block';
        } else {
            // Show spinning icon
            syncIcon.style.display = 'block';
            syncIcon.style.animation = 'spin 1s linear infinite';
            syncTimerSpan.style.display = 'none';
        }
    } else { // Timer not active
        syncIcon.style.display = 'block';
        syncIcon.style.animation = 'none';
        syncTimerSpan.style.display = 'none';
        syncTimerSpan.innerText = '';
    }
}

function startSyncTimer() {
    if (syncTimerInterval) return; // Avoid multiple timers
    
    syncCountdown = SYNC_RESET_TIME;
    updateSyncButtonState();

    syncTimerInterval = setInterval(() => {
        syncCountdown--;
        updateSyncButtonState();

        if (syncCountdown <= 0) {
            stopSyncTimer();
            resetDpsMeter();
        }
    }, 1000);
}

function stopSyncTimer() {
    clearInterval(syncTimerInterval);
    syncTimerInterval = null;
    clearTimeout(syncTimerDisplayTimeout);
    updateSyncButtonState();
}

// Formatting functions
function formatStat(value) {
    if (value >= 1000000000000) {
        return (value / 1000000000000).toFixed(1) + 'T';
    }
    if (value >= 1000000000) {
        return (value / 1000000000).toFixed(1) + 'G';
    }
    if (value >= 1000000) {
        return (value / 1000000).toFixed(1) + 'M';
    }
    if (value >= 1000) {
        return (value / 1000).toFixed(1) + 'k';
    }
    return value.toFixed(0);
}

function getHealthColor(percentage) {
    if (percentage > 75) return '#1db954'; // Green
    if (percentage > 50) return '#28a745'; // Light green
    if (percentage > 25) return '#f39c12'; // Orange
    return '#e74c3c'; // Red
}

// Position background colors (gradient from red to blue)
const positionBackgroundColors = [
    'rgba(180, 50, 60, 0.35)',     // 1st - Dark red
    'rgba(170, 60, 70, 0.32)',     // 2nd - Medium dark red
    'rgba(160, 70, 80, 0.29)',     // 3rd - Medium red
    'rgba(150, 80, 90, 0.26)',     // 4th - Faded red
    'rgba(140, 90, 100, 0.23)',    // 5th - Reddish gray
    'rgba(120, 100, 110, 0.20)',   // 6th - Medium gray
    'rgba(100, 110, 120, 0.17)',   // 7th - Bluish gray
    'rgba(80, 120, 130, 0.14)',    // 8th - Grayish blue
    'rgba(70, 130, 140, 0.11)',    // 9th - Dark blue
    'rgba(60, 140, 150, 0.08)'     // 10th - Very dark blue
];

function getPositionBackgroundColor(index) {
    return positionBackgroundColors[index] || positionBackgroundColors[9];
}

// Sorting function
function sortUserArray(userArray) {
    userArray.sort((a, b) => {
        let aVal, bVal;
        
        switch(sortColumn) {
            case 'totalDmg':
                aVal = a.total_damage?.total ? Number(a.total_damage.total) : 0;
                bVal = b.total_damage?.total ? Number(b.total_damage.total) : 0;
                break;
            
            case 'dmgTaken':
                aVal = Number(a.taken_damage) || 0;
                bVal = Number(b.taken_damage) || 0;
                break;
            
            case 'totalHeal':
                aVal = a.total_healing?.total ? Number(a.total_healing.total) : 0;
                bVal = b.total_healing?.total ? Number(b.total_healing.total) : 0;
                break;
            
            case 'dps':
                aVal = Number(a.total_dps) || 0;
                bVal = Number(b.total_dps) || 0;
                break;
            
            case 'hps':
                aVal = Number(a.total_hps) || 0;
                bVal = Number(b.total_hps) || 0;
                break;
            
            default:
                aVal = a.total_damage?.total ? Number(a.total_damage.total) : 0;
                bVal = b.total_damage?.total ? Number(b.total_damage.total) : 0;
        }
        
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    });
}

// Main data fetch and render function
async function fetchDataAndRender() {
    const container = document.getElementById('player-bars-container');
    try {
        // Use correct API based on view mode
        const apiEndpoint = viewMode === 'solo' ? '/api/solo-user' : '/api/data';
        
        const [dataRes, diccRes] = await Promise.all([
            fetch(apiEndpoint),
            fetch('/api/diccionario')
        ]);
        
        const userData = await dataRes.json();
        const diccionarioData = await diccRes.json();

        // Detect server reset (channel change or manual)
        if (userData.startTime && userData.startTime !== lastStartTime) {
            console.log('Server reset detected. Clearing local state.');
            lastStartTime = userData.startTime;
            lastTotalDamage = 0;
            stopSyncTimer();
        }

        // Convert users object to array
        let userArray = Object.entries(userData.user).map(([uid, data]) => ({
            ...data,
            uid: parseInt(uid, 10)
        }));
        
        // Filter users with activity
        userArray = userArray.filter(u => 
            (u.total_damage && u.total_damage.total > 0) || 
            (u.taken_damage > 0) || 
            (u.total_healing && u.total_healing.total > 0)
        );

        if (!userArray || userArray.length === 0) {
            loadingIndicator.style.display = 'flex';
            playerBarsContainer.style.display = 'none';
            return;
        }

        loadingIndicator.style.display = 'none';
        playerBarsContainer.style.display = 'flex';

        // Calculate total damage for percentages
        const sumaTotalDamage = userArray.reduce((acc, u) => 
            acc + (u.total_damage && u.total_damage.total ? Number(u.total_damage.total) : 0), 0
        );

        // Auto-sync timer: start if damage is increasing
        if (sumaTotalDamage > lastTotalDamage) {
            lastTotalDamage = sumaTotalDamage;
            lastDamageChangeTime = Date.now();
            if (!syncTimerInterval) {
                startSyncTimer();
            }
        } else if (sumaTotalDamage === 0 && lastTotalDamage > 0) {
            // Data was cleared
            lastTotalDamage = 0;
            lastDamageChangeTime = Date.now();
            stopSyncTimer();
        }

        // Calculate damage percentages
        userArray.forEach(u => {
            const userDamage = u.total_damage && u.total_damage.total ? Number(u.total_damage.total) : 0;
            u.damagePercent = sumaTotalDamage > 0 ? Math.max(0, Math.min(100, (userDamage / sumaTotalDamage) * 100)) : 0;
            
            // Calculate healing percentages
            const totalHealing = userArray.reduce((acc, user) => 
                acc + (user.total_healing && user.total_healing.total ? Number(user.total_healing.total) : 0), 0
            );
            const userHealing = u.total_healing && u.total_healing.total ? Number(u.total_healing.total) : 0;
            u.healingPercent = totalHealing > 0 ? Math.max(0, Math.min(100, (userHealing / totalHealing) * 100)) : 0;
        });

        // Get local user UID
        let localUid = null;
        if (viewMode === 'solo') {
            const uidKey = Object.keys(userData.user)[0];
            localUid = uidKey ? parseInt(uidKey, 10) : null;
        } else {
            try {
                const localUserResponse = await fetch('/api/solo-user');
                const localUserData = await localUserResponse.json();
                if (localUserData.user && Object.keys(localUserData.user).length > 0) {
                    localUid = parseInt(Object.keys(localUserData.user)[0], 10);
                }
            } catch (err) {
                console.log('Could not get local user:', err);
            }
        }

        // Sort array
        sortUserArray(userArray);
        
        // Group players by party if in nearby mode
        let groupedUsers = [];
        if (viewMode === 'nearby') {
            // Separate party members and non-party members
            const partyUsers = userArray.filter(u => u.isPartyMember);
            const nonPartyUsers = userArray.filter(u => !u.isPartyMember);
            
            // Show party members first, then others
            if (partyUsers.length > 0) {
                groupedUsers = [...partyUsers, ...nonPartyUsers];
            } else {
                groupedUsers = userArray;
            }
        } else {
            groupedUsers = userArray;
        }

        // Render player bars
        container.innerHTML = groupedUsers.map((u, index) => {
            const professionParts = (u.profession || '-').split('-');
            const mainProfessionKey = professionParts[0];
            const subProfessionKey = professionParts[1];
            const mainProf = professionMap[mainProfessionKey] || defaultProfession;
            const subProf = professionMap[subProfessionKey];
            const prof = subProf || mainProf;
            let professionName = mainProf.name;
            if (subProf) {
                professionName += ` - ${subProf.name}`;
            }
            
            const dps = Number(u.total_dps) || 0;
            const hps = Number(u.total_hps) || 0;
            const totalDmg = u.total_damage && u.total_damage.total ? Number(u.total_damage.total) : 0;
            const dmgTaken = Number(u.taken_damage) || 0;
            const totalHeal = u.total_healing && u.total_healing.total ? Number(u.total_healing.total) : 0;
            const nombre = u.name || 'Unknown';
            const gs = u.fight_point || 0;
            
            const hpPercent = ((u.hp || 0) / (u.max_hp || 1)) * 100;
            const hpColor = getHealthColor(hpPercent);
            const bgColor = getPositionBackgroundColor(index);
            
            // Position styling
            const position = index + 1;
            const isLocalPlayer = localUid && u.uid === localUid;
            let positionClasses = 'player-position';
            
            if (position === 1) positionClasses += ' rank-1';
            else if (position === 2) positionClasses += ' rank-2';
            else if (position === 3) positionClasses += ' rank-3';
            
            if (isLocalPlayer) positionClasses += ' local-player';
            
            // Role indicators
            const roleIndicator = prof.isTank ? '🛡️' : (prof.isHealer ? '❤️' : '⚔️');
            const roleColor = prof.isTank ? '#4a9eff' : (prof.isHealer ? '#1db954' : '#ff6b6b');
            const roleText = prof.role.toUpperCase();
            
            // Party indicator
            const partyIndicator = u.isPartyMember ? '<span style="color: #ffaa00; margin-right: 4px;" title="Party Member">👥</span>' : '';
            const raidIndicator = u.raidGroup ? `<span style="color: #ff6b6b; margin-right: 4px;" title="Raid Group ${u.raidGroup}">🔷G${u.raidGroup}</span>` : '';
            
            return `<div class="player-bar ${u.isPartyMember ? 'party-member' : ''}" style="--damage-percent: ${u.damagePercent}%; --damage-bg-color: ${bgColor};">
                <div class="player-info">
                    <span class="${positionClasses}">${position}</span>
                    <img class="class-icon" src="icons/${prof.icon}" alt="${professionName}" title="${professionName}">
                    <div class="player-details">
                        <span class="player-name">
                            ${partyIndicator}${raidIndicator}${nombre} 
                            <span style="color: ${roleColor}; font-size: 10px; font-weight: 700; margin-left: 4px;">${roleIndicator} ${roleText}</span>
                            <span style="color: var(--text-secondary); font-size: 10px; font-weight: 400;">(GS: ${gs})</span>
                        </span>
                        <div class="hp-bar">
                            <div class="hp-fill" style="width: ${hpPercent}%; background: ${hpColor};"></div>
                            <span class="hp-text">${formatStat(u.hp || 0)}/${formatStat(u.max_hp || 0)}</span>
                        </div>
                    </div>
                    <div class="player-stats-main">
                        <div class="stat">
                            <span class="stat-label">DPS</span>
                            <span class="stat-value">${formatStat(dps)}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">HPS</span>
                            <span class="stat-value">${formatStat(hps)}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">TOTAL DMG</span>
                            <span class="stat-value">${formatStat(totalDmg)}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">DMG TAKEN</span>
                            <span class="stat-value">${formatStat(dmgTaken)}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">% DMG</span>
                            <span class="stat-value">${Math.round(u.damagePercent)}%</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">TOTAL HEAL</span>
                            <span class="stat-value">${formatStat(totalHeal)}</span>
                        </div>
                    </div>
                </div>
            </div>`;
        }).join('');
        
    } catch (err) {
        console.error('Error in fetchDataAndRender:', err);
        if (container) {
            container.innerHTML = '<div style="padding: 20px; text-align: center; color: var(--text-secondary);">Waiting for game data...</div>';
        }
        loadingIndicator.style.display = 'flex';
        playerBarsContainer.style.display = 'none';
    } finally {
        updateSyncButtonState();
    }
}

// Update UI every 50ms for smooth real-time updates
setInterval(fetchDataAndRender, 50);
fetchDataAndRender();
