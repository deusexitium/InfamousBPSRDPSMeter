
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { exec, fork } = require('child_process');
const net = require('net'); // Required for checkPort
const fs = require('fs');

// Function to log to file safely for packaged environment
function logToFile(msg) {
    try {
        const userData = app.getPath('userData');
        const logPath = path.join(userData, 'iniciar_log.txt');
        const timestamp = new Date().toISOString();
        fs.mkdirSync(userData, { recursive: true });
        fs.appendFileSync(logPath, `[${timestamp}] ${msg}\n`);
    } catch (e) {
        // If there's an error, show in console
        console.error('Error writing log:', e);
    }
}


let mainWindow;
let serverProcess;
let server_port = 8989; // Initial port
let isLocked = false; // Initial lock state: unlocked
logToFile('==== ELECTRON START ====');

    // Function to check if a port is in use
    const checkPort = (port) => {
        return new Promise((resolve) => {
            const server = net.createServer();
            server.once('error', () => resolve(false));
            server.once('listening', () => {
                server.close(() => resolve(true));
            });
            server.listen(port);
        });
    };

    async function findAvailablePort() {
        let port = 8989;
        while (true) {
            if (await checkPort(port)) {
                return port;
            }
            console.warn(`Port ${port} is already in use, trying next...`);
            port++;
        }
    }

    // Function to kill the process using a specific port
    async function killProcessUsingPort(port) {
        return new Promise((resolve) => {
            exec(`netstat -ano | findstr :${port}`, (error, stdout, stderr) => {
                if (stdout) {
                    const lines = stdout.split('\n').filter(line => line.includes('LISTENING'));
                    if (lines.length > 0) {
                        const pid = lines[0].trim().split(/\s+/).pop();
                        if (pid) {
                            console.log(`Killing process ${pid} using port ${port}...`);
                            exec(`taskkill /PID ${pid} /F`, (killError, killStdout, killStderr) => {
                                if (killError) {
                                    console.error(`Error killing process ${pid}: ${killError.message}`);
                                } else {
                                    console.log(`Process ${pid} killed successfully.`);
                                }
                                resolve();
                            });
                        } else {
                            resolve();
                        }
                    } else {
                        resolve();
                    }
                } else {
                    resolve();
                }
            });
        });
    }

    async function createWindow() {
        logToFile('Attempting to kill processes on port 8989...');
        await killProcessUsingPort(8989);

        server_port = await findAvailablePort();
        logToFile('Available port found: ' + server_port);

        mainWindow = new BrowserWindow({
            width: 650,
            height: 600,
            transparent: true,
            frame: false,
            alwaysOnTop: true,
            resizable: true, // Allow resizing for scrollable content
            webPreferences: {
                preload: path.join(__dirname, 'preload.js'),
                nodeIntegration: false,
                contextIsolation: true,
            },
            icon: path.join(__dirname, 'icon.ico'),
        });

        // Configure window to always stay on top with maximum priority
        mainWindow.setAlwaysOnTop(true, 'screen-saver');
        
        // Start with mouse events ENABLED so dragging works
        // We'll handle click-through in CSS with pointer-events
        mainWindow.setIgnoreMouseEvents(false);

        // Start the Node.js server, passing the port as argument

        // Determine absolute path to server.js based on environment
        let serverPath;
        if (process.defaultApp || process.env.NODE_ENV === 'development') {
            // Development mode
            serverPath = path.join(__dirname, 'server.js');
        } else {
            // Packaged mode: use app.getAppPath() to access within asar
            serverPath = path.join(app.getAppPath(), 'server.js');
        }
        logToFile('Launching server.js on port ' + server_port + ' with path: ' + serverPath);

        // Use fork to launch the server as child process
        const { fork } = require('child_process');
        serverProcess = fork(serverPath, [server_port], {
            stdio: ['pipe', 'pipe', 'pipe', 'ipc'],
            execArgv: []
        });

        // Variables to control server startup
        if (typeof createWindow.serverLoaded === 'undefined') createWindow.serverLoaded = false;
        if (typeof createWindow.serverTimeout === 'undefined') createWindow.serverTimeout = null;
        createWindow.serverLoaded = false;
        createWindow.serverTimeout = setTimeout(() => {
            if (!createWindow.serverLoaded) {
                logToFile('ERROR: Server did not respond in time.');
                mainWindow.loadURL('data:text/html,<h2 style="color:red">Error: Server did not respond in time.<br>Check iniciar_log.txt for more details.</h2>');
            }
        }, 10000); // 10 seconds timeout

        serverProcess.stdout.on('data', (data) => {
            logToFile('server stdout: ' + data);
            const match = data.toString().match(/Web server started on (http:\/\/localhost:\d+)/);
            if (match && match[1]) {
                const serverUrl = match[1];
                logToFile('Loading URL in window: ' + serverUrl + '/index.html');
                mainWindow.loadURL(`${serverUrl}/index.html`);
                createWindow.serverLoaded = true;
                clearTimeout(createWindow.serverTimeout);
            }
        });
        serverProcess.stderr.on('data', (data) => {
            logToFile('server stderr: ' + data);
        });
        serverProcess.on('close', (code) => {
            logToFile('server process exited with code ' + code);
        });


        // Ensure window stays on top when gaining focus (fixes Alt+Tab issues)
        mainWindow.on('focus', () => {
            if (mainWindow && !mainWindow.isDestroyed()) {
                mainWindow.setAlwaysOnTop(true, isLocked ? 'screen-saver' : 'normal');
            }
        });

        // Handle minimize/restore events to maintain always-on-top behavior
        mainWindow.on('minimize', () => {
            // When minimized and then restored, ensure always-on-top is maintained
            setTimeout(() => {
                if (mainWindow && !mainWindow.isDestroyed()) {
                    mainWindow.setAlwaysOnTop(true, isLocked ? 'screen-saver' : 'normal');
                }
            }, 100);
        });

        mainWindow.on('restore', () => {
            if (mainWindow && !mainWindow.isDestroyed()) {
                mainWindow.setAlwaysOnTop(true, isLocked ? 'screen-saver' : 'normal');
            }
        });

        mainWindow.on('closed', () => {
            mainWindow = null;
            if (serverProcess) {
                // Send SIGTERM for clean shutdown
                serverProcess.kill('SIGTERM');
                // Force termination if it doesn't close after some time
                setTimeout(() => {
                    if (!serverProcess.killed) {
                        serverProcess.kill('SIGKILL');
                    }
                }, 5000);
            }
        });

    // Handle event to make window movable/unmovable
    ipcMain.on('set-window-movable', (event, movable) => {
        if (mainWindow) {
            mainWindow.setMovable(movable);
        }
    });

    // Handle event to close the window
    ipcMain.on('close-window', () => {
        if (mainWindow) {
            mainWindow.close();
        }
    });

    // Handle event to resize the window
    ipcMain.on('resize-window', (event, width, height) => {
        if (mainWindow) {
            mainWindow.setSize(width, height);
        }
    });

    // Handle events for mouse click-through control
    ipcMain.on('set-ignore-mouse-events', (event, ignore, options) => {
        if (mainWindow) {
            mainWindow.setIgnoreMouseEvents(ignore, options);
        }
    });

    // Handle window position for manual drag (fallback)
    ipcMain.handle('get-window-position', () => {
        if (mainWindow) {
            return mainWindow.getPosition();
        }
        return [0, 0];
    });

    ipcMain.on('set-window-position', (event, x, y) => {
        if (mainWindow) {
            mainWindow.setPosition(x, y);
        }
    });

    // Handle event to toggle lock state
    ipcMain.on('toggle-lock-state', () => {
        if (mainWindow) {
            isLocked = !isLocked;
            mainWindow.setMovable(!isLocked); // Make window movable or not
            // Don't use setIgnoreMouseEvents here - let CSS/JS handle click-through
            // The renderer will manage mouse event state based on lock status
            mainWindow.webContents.send('lock-state-changed', isLocked); // Notify renderer
            console.log(`Lock: ${isLocked ? 'Locked' : 'Unlocked'}`);
        }
    });

    // Send initial lock state to renderer once window is ready
    mainWindow.webContents.on('did-finish-load', () => {
        mainWindow.webContents.send('lock-state-changed', isLocked);
    });
}

app.whenReady().then(() => {
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});
