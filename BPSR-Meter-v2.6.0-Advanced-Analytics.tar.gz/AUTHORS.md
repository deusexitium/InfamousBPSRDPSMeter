# Authors and Contributors

This project is based on the original work by:

*   **dmlgzs** - [StarResonanceDamageCounter](https://github.com/dmlgzs/StarResonanceDamageCounter)

We thank dmlgzs for their initial work that served as the foundation for this project.
