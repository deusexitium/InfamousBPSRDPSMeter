# BPSR Meter v2.5.1 - Critical Fixes Update

## 🔧 Critical Fixes (Phase 1)

### 1. ✅ FIXED: Drag Button Now Works!
**Problem:** Window couldn't be dragged due to click-through system blocking
**Solution:**
- Window now always accepts mouse events at Electron level
- CSS `pointer-events` controls click-through per element
- `.controls` always has `pointer-events: auto`
- `.drag-indicator` always draggable with `-webkit-app-region: drag`

**Result:** Window dragging is now instant and smooth!

### 2. ✅ FIXED: No More Player Limit!
**Problem:** Hardcoded to show only top 10 players
**Solution:**
- Removed top 10 limit completely
- All players now shown in sorted list
- Added scrollable container (`max-height: 70vh`)
- Custom scrollbar styling

**Result:** See ALL players in your instance, not just top 10!

### 3. ✅ ADDED: Role Detection
**Problem:** No way to identify tanks vs DPS
**Solution:**
- Added `isTank` and `isHealer` flags to all professions
- Visual role indicators:
  - 🛡️ TANK (blue) - For tank classes
  - ❤️ HEALER (green) - For healer classes
  - ⚔️ DPS (red) - For DPS classes
- Role text shown next to player name

**Result:** Instantly identify player roles!

### 4. ✅ ADDED: Party Member Indicators
**Problem:** No visual indication of party members
**Solution:**
- Party members tracked in dataManager
- 👥 icon shown for party members
- Gold border-left on party member bars
- Golden background tint
- Party members grouped at top

**Result:** Easily see who's in your party!

## 🚀 Advanced Features (Phase 2)

### 5. ✅ Party/Raid Infrastructure Added
**Added to dataManager:**
- `partyMembers` Set - Tracks party UIDs
- `raidMembers` Map - Tracks raid groups
- `addPartyMember()`, `removePartyMember()` methods
- `isPartyMember()` check
- `setRaidGroup()`, `getRaidGroup()` methods

**Added API endpoint:**
- `GET /api/party-info` - Returns party and raid data

**Added to user data:**
- `isPartyMember` flag in user summary
- `raidGroup` ID in user summary  
- `isLocalPlayer` flag in user summary

**Visual indicators:**
- 👥 icon for party members
- 🔷G# for raid group members
- Gold left border for party
- Grouped display (party first)

### 6. ✅ Improved UI Polish
**Window:**
- Now resizable (for scrolling)
- `max-height: 90vh` on meter
- Smooth scrollbar with custom styling
- Body `pointer-events: none` for click-through

**Controls:**
- All buttons properly clickable
- Drag handle larger (28px)
- Lock mode only keeps lock button
- Better visual feedback

## 📊 What's Changed

### Modified Files:
- `electron-main.js` - Resizable window, removed forced click-through
- `public/css/style.css` - Added party styling, scrolling, pointer-events
- `public/js/main.js` - Removed player limit, added role indicators, simplified click-through
- `src/server/dataManager.js` - Added party/raid tracking
- `src/server/api.js` - Added party-info endpoint

### New Features Count:
- 6 critical fixes
- 4 new visual indicators (role, party, raid, scrolling)
- 8 new dataManager methods
- 1 new API endpoint

## 🎯 Testing Checklist

- [ ] Window dragging works smoothly
- [ ] All players shown (not just top 10)
- [ ] Scrollbar appears with many players
- [ ] Role icons visible (🛡️/❤️/⚔️)
- [ ] Role text shows (TANK/HEALER/DPS)
- [ ] Lock button still works
- [ ] All other buttons clickable
- [ ] Player bars click-through
- [ ] Alt+Tab keeps window visible

## ⚠️ Known Limitations

**Party Detection:**
- Infrastructure is in place
- Packet-level detection needs protobuf analysis
- Currently marks based on data (will auto-populate when packets parsed)
- May need game testing to identify party packets

**Name Detection:**
- "Unknown" players occur when:
  - Meter started after players joined
  - Name packet not yet received
  - Network packet loss
- **Workaround:** Change instance to refresh
- **Future:** Better async name resolution

## 🔜 Future Enhancements

### Short-term:
- [ ] Parse team/party packets from protobuf
- [ ] Better async name resolution
- [ ] Configurable player limit option
- [ ] Horizontal scroll for more stats

### Long-term:
- [ ] Skill breakdown tracking
- [ ] Damage timeline charts
- [ ] Buff uptime tracking
- [ ] Combat log export
- [ ] Custom themes

---

**Version:** 2.5.1
**Release Date:** October 22, 2025
**Compatibility:** Windows 10/11, Blue Protocol Star Resonance
